
import {additem,addqty,Empty,ritem, rqty} from './actiontypes';



export const add2cart = (data) =>{
    return{
        type: additem,
        food: data
    }
}

export const add = (data,qty) =>{
    return{
        type: addqty,
        food: data,
        qty
    }
}

export const minus = (data,qty) =>{
    return{
        type: rqty,
        food: data,
        qty
    }
}
export const removeitem = (data,qty) => {
    return{
        type: ritem,
        food: data,
        qty
        
    }
}

export const Emptycart = (bool) => {
    return{
        type: Empty,
        
        
    }
}




