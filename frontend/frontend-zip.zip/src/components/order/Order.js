import React from 'react'
import Nav from '../Home/Nav'
import './Order.css'
function Order() {
    const people = [
        { id: "bdkjfh5iyhfuide", name: "Johnny", status: "completed", item: 30 },
        { id: "bdkjfh5iyhfuide", name: "Jenny", status: "pending", item: 28 },
        { id: "bdkjfh5iyhfuide", name: "Sam", status: "completed", item: 13 },
        { id: "bdkjfh5iyhfuide", name: "Johnny", status: "completed", item: 30 },
        { id: "bdkjfh5iyhfuide", name: "Jenny", status: "pending", item: 28 },
        { id: "bdkjfh5iyhfuide", name: "Sam", status: "completed", item: 13 },
        { id: "bdkjfh5iyhfuide", name: "Johnny", status: "completed", item: 30 },
        { id: "bdkjfh5iyhfuide", name: "Jenny", status: "pending", item: 28 },
        { id: "bdkjfh5iyhfuide", name: "Sam", status: "completed", item: 13 },
        { id: "bdkjfh5iyhfuide", name: "Johnny", status: "completed", item: 30 },
        { id: "bdkjfh5iyhfuide", name: "Jenny", status: "pending", item: 28 },
        { id: "bdkjfh5iyhfuide", name: "Sam", status: "completed", item: 13 },
        { id: "bdkjfh5iyhfuide", name: "Dean", status: "pending", item: 8 }
      ];
  return (
    <>
    <Nav />
    <table className='table-container'>
<thead><tr>
    
<th>Order ID</th>
    
    <th>Username</th>
    
    <th>Status</th>
    
    <th>Items</th>
</tr>
</thead>

<tbody>
    {
        people.map(item => {
            return(
                <>
                <tr>
        <td>{item.id}</td>
        <td>{item.name}</td>
        <td>{item.status}</td>
        <td>{item.item}</td>
                </tr>
                </>
            )
        })
    }
</tbody>
    </table>
    



    </>
  )
}

export default Order