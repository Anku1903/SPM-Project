import axios from 'axios'
import React,{useState,useEffect} from 'react'
import { serverurl } from '../Helper/help'
import {useParams} from 'react-router-dom'
import toast, { Toaster } from 'react-hot-toast';
import Nav from '../Home/Nav'
import './Explore.css'
function Visite() {
  const {id} = useParams()
  const maketoast = () => {
    toast.success("Item added to cart!!")
  }

    const [restaurent, setrestaurent] = useState({})
    const [fooddata, setfooddata] = useState([])
  

    useEffect(() => {
     

      axios.get(serverurl+"/api/restaurents/"+id).then(response => {
        console.log(response.data.oneshop)
        if(response.data.oneshop){
          setrestaurent(response.data.oneshop)
          
        }
      })

    }, [])

    useEffect(() => {
      axios.post(serverurl+"/api/fooditems",{id: restaurent._id,name: restaurent.name}).then(res => {
        if(res.data.fooddata){
          setfooddata(res.data.fooddata)
          
        }
      })
    }, [restaurent])
  return (
    <>
    <Nav />

    <section className='home' id='home'>
        <div className='home-div'>
          <h1> {restaurent.name}</h1>
          <a href='/explore' className='home-btn'>Rating {restaurent.rating}</a>
        </div>
        <div className='home-img'>
          <img src={restaurent.logo} alt='burger' />
        </div>
      </section>


      <section className='popular' id='popular'>

      <h1 className='popular-heading'>ALL <span>Dishes</span></h1>
<div className='box-container'>

{fooddata && fooddata.map(item => {
  return(
    <>
    <div className='box'>
  <img src={item.image} alt='burger' />
  <h3>{item.name}</h3>
  <a onClick={maketoast} className='box-btn'>₹ {item.price} ADD</a>
  <Toaster />
</div>
    </>
  )
})}


</div>
      </section>


    </>
  )
}

export default Visite