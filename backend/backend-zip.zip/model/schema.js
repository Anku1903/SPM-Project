const mongoose = require('mongoose');
const Userschema = new mongoose.Schema({
    name: {type: String,required:true},
    email: {type:String,required: true,unique: true},
    password: {type:String,required: true},
    isowner: {type: String,required:true}


},{timestamps: true})


const foodSchema = new mongoose.Schema({
    name: {type: String,required: true},
    price: {type: String,required: true},
    shopname: {type: String,required: true},
    category: {type: String,required: true},
    image: {type: String,required: true},
})


const Shopschema = new mongoose.Schema({
    name: {type: String,required:true},
    rating: {type:String,required: true},
    category: {type:Array,required: true},
    logo: {type:String,required: true}
})

exports.fooditem = mongoose.model('FoodItem',foodSchema);

exports.user = mongoose.model('FoodUsers',Userschema);


exports.restora = mongoose.model('FoodShop',Shopschema);