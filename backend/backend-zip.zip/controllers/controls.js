const mongoose = require("mongoose")
const {user,fooditem} = require('../model/schema')
exports.register = (req,res) => {
    const {name,email,password,isowner} = req.body;

    const newfooduser = new user({
        name,
        email,
        password,
        isowner
    }).save((err,data) => {
    
        if(err) {
            res.json({result: 'server Error !'})
        }
        else{
            res.json({result: data})
        }
    })



}

exports.login = (req,res) => {
    const {email,password} = req.body;

const user = mongoose.model("FoodUsers")
user.findOne({email},(err,data) =>{
    if(err){
        
        return res.json({result: "Database Error"})
    }
    if(!data){
        return res.json({result: "User does not exist"})
    }
    else{
        if(password!==data.password){
         
        return res.json({result: "Wrong password"})   
        }
        else{
            
        return res.json({result: "You're logged in.",userdata: data})
        }
    }

    

})

}


exports.restaurents = (req,res) => {
    const newShop = mongoose.model('FoodShop');
            newShop.find((err,data) => {
                if(err) {
                    console.log(err);
                    res.status(401).json({error: 'Database error'})
                }
                else{
                    res.json({restaurents: data})
                }
            })
}

exports.onerestora = (req,res) => {
    const id = req.params.id
    
    const newShop = mongoose.model('FoodShop');
            newShop.findOne({_id:id},(err,data) => {
                if(err) {
                    console.log(err);
                    res.status(401).json({error: 'Database error'})
                }
                else{
                    let objdata = {_id:data._id,name: data.name,category: data.category,rating: data.rating,logo: data.logo}
                   return res.json({oneshop: objdata})
                }
            })
}


exports.finditems = (req,res) => {
    const {id,name} = req.body
    
    const newFood = mongoose.model('FoodItem');
            fooditem.find({shopname:name},(err,data) => {
                if(err) {
                    console.log(err);
                    res.status(401).json({error: 'Database error'})
                }
                else{
                   return res.json({fooddata: data})
                }
            })
}